const steps = document.querySelectorAll(".form-step");
const progress = document.querySelector(".progress");
let current = 0;
document.querySelectorAll(".next").forEach(btn => {
  btn.onclick = () => {
    steps[current].classList.remove("active");
    current++;
    steps[current].classList.add("active");
    progress.style.width = `${(current / (steps.length - 1)) * 100}%`;
  };
});
document.querySelectorAll(".prev").forEach(btn => {
  btn.onclick = () => {
    steps[current].classList.remove("active");
    current--;
    steps[current].classList.add("active");
    progress.style.width = `${(current / (steps.length - 1)) * 100}%`;
  };
});
