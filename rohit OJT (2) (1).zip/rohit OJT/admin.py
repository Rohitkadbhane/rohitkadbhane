from flask import Flask, render_template_string
import mysql.connector

app = Flask(__name__)

@app.route('/admin')
def admin_dashboard():
    db = mysql.connector.connect(host="localhost", user="root", password="Kadbhane@123", database="onboarding")
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM clients ORDER BY submitted_at DESC")
    clients = cursor.fetchall()
    cursor.close()

    html = """
    <h2>Admin Dashboard - Client Submissions</h2>
    <table border="1" cellpadding="10">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Submitted At</th></tr>
        {% for client in clients %}
        <tr>
            <td>{{ client.id }}</td>
            <td>{{ client.full_name }}</td>
            <td>{{ client.email }}</td>
            <td>{{ client.phone }}</td>
            <td>{{ client.company_name }}</td>
            <td>{{ client.submitted_at }}</td>
        </tr>
        {% endfor %}
    </table>
    """
    return render_template_string(html, clients=clients)

if __name__ == '__main__':
    app.run(port=5000, debug=True)
