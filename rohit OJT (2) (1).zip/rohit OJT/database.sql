CREATE DATABASE IF NOT EXISTS onboarding;

USE onboarding;

CREATE TABLE IF NOT EXISTS clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(20),
    company_name VARCHAR(255),
    website VARCHAR(255),
    address TEXT,
    business_type VARCHAR(255),
    industry_sector VARCHAR(255),
    description TEXT,
    goals TEXT,
    marketing_needs TEXT,
    custom_requests TEXT,
    software_type VARCHAR(100),
    features TEXT,
    timeline VARCHAR(100),
    budget VARCHAR(100),
    competitors TEXT,
    referral VARCHAR(255),
    communication VARCHAR(255),
    language VARCHAR(100),
    logo_path TEXT,
    brochure_paths TEXT,
    brand_guidelines_path TEXT,
    submitted_at DATETIME
);
