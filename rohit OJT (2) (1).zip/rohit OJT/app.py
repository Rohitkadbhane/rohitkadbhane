from flask import Flask, request, redirect, render_template_string
import mysql.connector
import os
from datetime import datetime
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def send_email(subject, body, to_email):
    sender =  "your_email@example.com"
    password = "your_password"
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = to_email

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(sender, password)
            smtp.send_message(msg)
        print("Email sent successfully.")
    except Exception as e:
        print("Error sending email:", e)

@app.route('/submit', methods=['POST'])
def submit():
    form = request.form
    files = request.files
    logo = files['logo']
    brochures = files.getlist('brochures')
    brand_guidelines = files['brand_guidelines']

    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    logo_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(logo.filename))
    logo.save(logo_path)

    brochures_paths = []
    for brochure in brochures:
        if allowed_file(brochure.filename):
            path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(brochure.filename))
            brochure.save(path)
            brochures_paths.append(path)

    guidelines_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(brand_guidelines.filename))
    brand_guidelines.save(guidelines_path)

    db = mysql.connector.connect(host="localhost", user="root", password="Kadbhane@123", database="onboarding")
    cursor = db.cursor()

    cursor.execute("""INSERT INTO clients (full_name, email, phone, company_name, website, address, business_type, 
                    industry_sector, description, goals, marketing_needs, custom_requests, software_type, features, 
                    timeline, budget, competitors, referral, communication, language, logo_path, brochure_paths, 
                    brand_guidelines_path, submitted_at) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""", (
        form['full_name'], form['email'], form['phone'], form['company_name'], form['website'], form['address'],
        form['business_type'], form['industry_sector'], form['description'], form['goals'],
        ','.join(request.form.getlist('marketing_needs')), form['custom_requests'],
        form['software_type'], form['features'], form['timeline'], form['budget'], form['competitors'],
        form['referral'], form['communication'], form['language'], logo_path, ','.join(brochures_paths), guidelines_path,
        datetime.now()
    ))

    db.commit()
    cursor.close()

    send_email("Thanks for submitting!", "We have received your details.", form['email'])
    send_email("New Client Submission", f"New form submitted by {form['full_name']}", "admin@example.com")

    return redirect('/thankyou')

@app.route('/thankyou')
def thank_you():
    return "<h2>Thank you for submitting your information!</h2>"

if __name__ == '__main__':
    app.run(debug=True, port=8000)
